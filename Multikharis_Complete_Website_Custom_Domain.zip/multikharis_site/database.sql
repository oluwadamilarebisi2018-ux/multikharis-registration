CREATE TABLE registrations (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, reference_no VARCHAR(32) NOT NULL UNIQUE,
 surname VARCHAR(100) NOT NULL, first_name VARCHAR(100) NOT NULL, other_names VARCHAR(150), passport_path VARCHAR(255),
 gender VARCHAR(10) NOT NULL, date_of_birth DATE NOT NULL, phone VARCHAR(30) NOT NULL, whatsapp VARCHAR(30) NOT NULL,
 email VARCHAR(190) NOT NULL, home_address TEXT NOT NULL, state_of_origin VARCHAR(100) NOT NULL, lga VARCHAR(120) NOT NULL,
 participant_category VARCHAR(30) NOT NULL, institution VARCHAR(190) NOT NULL, discipline VARCHAR(150) NOT NULL,
 student_level VARCHAR(80), matric_no VARCHAR(100), state_code VARCHAR(100), callup_no VARCHAR(120), ppa VARCHAR(190),
 skills TEXT NOT NULL, skill_level VARCHAR(20) NOT NULL, training_mode VARCHAR(20) NOT NULL, schedule VARCHAR(30) NOT NULL,
 has_laptop TINYINT(1) DEFAULT 0, has_smartphone TINYINT(1) DEFAULT 0, has_internet TINYINT(1) DEFAULT 0,
 emergency_name VARCHAR(150) NOT NULL, emergency_relationship VARCHAR(100) NOT NULL, emergency_phone VARCHAR(30) NOT NULL,
 heard_about_us VARCHAR(100) NOT NULL, declaration_accepted TINYINT(1) NOT NULL, applicant_signature VARCHAR(150) NOT NULL,
 applicant_signed_date DATE NOT NULL, status ENUM('Pending','Accepted','Waitlisted') DEFAULT 'Pending', admin_note TEXT,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, INDEX(status), INDEX(created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE admins (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, username VARCHAR(80) UNIQUE NOT NULL, password_hash VARCHAR(255) NOT NULL);
