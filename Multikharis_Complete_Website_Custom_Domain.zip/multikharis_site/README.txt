MULTIKHARIS NIGERIA LIMITED — COMPLETE WEBSITE PACKAGE

FEATURES
- Responsive public website and five-step A5 registration form.
- Includes every A5 field in sections A–E: personal details, passport photo, participant category, institution/course/NYSC details, training skills/level/mode/schedule/equipment, emergency contact, referral source, declaration, signature and date.
- MySQL registration storage, unique registration reference, optional JPG/PNG/WebP passport upload (max 3 MB).
- Admin login and dashboard to view registrations and mark Pending / Accepted / Waitlisted.
- Contact details: Shop D7, College of Education, Warri, Delta State; Samuel 08106168576; Marvelous +234 812 882 9678; multikharisnigerialimited@gmail.com.

REQUIREMENTS
PHP 8.1+ with PDO MySQL and Fileinfo; MySQL/MariaDB; HTTPS; writable uploads/passports folder.

CUSTOM DOMAIN DEPLOYMENT (cPanel example)
1. Register your preferred domain and purchase PHP/MySQL hosting.
2. Point the domain DNS/nameservers to your hosting provider as instructed by them.
3. Create a MySQL database and database user in cPanel; grant all privileges.
4. Upload all package files into the domain document root (often public_html).
5. Copy config.example.php to config.php and fill in database host/name/user/password.
6. Import database.sql in phpMyAdmin.
7. Visit https://YOUR-DOMAIN/setup.php and create the first admin username and a unique password of at least 12 characters.
8. Delete setup.php from the server immediately after setup.
9. Sign in at https://YOUR-DOMAIN/admin.php. Ensure uploads/passports is writable by PHP (usually permissions 755 or 775 depending on host).
10. Enable SSL/HTTPS and test a registration, passport upload, and admin status update before sharing the link.

IMPORTANT
- The package is prepared source code; it is not yet published and no public link exists yet.
- You need a registered domain, hosting account, and their database credentials to deploy it.
- Enable SSL/HTTPS, use a unique strong admin password, back up database/uploads regularly, and test registration and admin access before sharing publicly.
- No course fees or payment gateway were present in the supplied A5 form, so none have been invented.
- No automated email sender is configured. The on-screen confirmation and reference number are provided; connect a verified email service if email notifications are required.
