<?php
require __DIR__.'/app.php';
$message='';
try {
  foreach (array_filter(array_map('trim', explode(';', file_get_contents(__DIR__.'/database.sql')))) as $query) db()->exec($query);
  if ($_SERVER['REQUEST_METHOD']==='POST') {
    checktoken();
    $username=trim($_POST['username']??''); $password=(string)($_POST['password']??'');
    if (strlen($username)<4 || strlen($password)<12) $message='Choose a username of at least 4 characters and a password of at least 12 characters.';
    elseif ((int)db()->query('SELECT COUNT(*) FROM admins')->fetchColumn()>0) $message='An admin account already exists. Sign in at admin.php.';
    else { $s=db()->prepare('INSERT INTO admins(username,password_hash) VALUES(?,?)'); $s->execute([$username,password_hash($password,PASSWORD_DEFAULT)]); $message='Admin account created. Delete setup.php from your hosting account now, then sign in at admin.php.'; }
  }
} catch(Throwable $e) { $message='Setup failed. Check config.php database details and import database.sql in phpMyAdmin.'; }
?>
<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Multikharis Setup</title><link rel="stylesheet" href="style.css"><body><main class="login"><h1>Multikharis website setup</h1><p>This creates the database tables and first administrator account.</p><?php if($message):?><p><?=h($message)?></p><?php endif;?><form method="post"><input type="hidden" name="csrf" value="<?=h(token())?>"><label>Admin username<input name="username" minlength="4" required></label><label>Admin password (12+ characters)<input type="password" name="password" minlength="12" required></label><button class="button" type="submit">Create admin account</button></form></main></body></html>
